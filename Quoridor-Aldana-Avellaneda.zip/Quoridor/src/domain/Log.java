package src.domain;

import java.io.Serializable;
import java.util.logging.Logger;
import java.util.logging.FileHandler;
import java.util.logging.SimpleFormatter;
import java.util.logging.Level;

/**
 *
 */
public class Log implements Serializable {
    public static String name = "Project";
    public static String logFilePath = "C:\\Users\\Asus\\Documents\\Escuela\\Sistemas\\2024-1 POOB\\proyectoFinal Quoridor\\Log errores\\" + name + ".log";

    public static void record(Exception e){
        try{
            Logger logger = Logger.getLogger(name);
            logger.setUseParentHandlers(false);
            FileHandler file = new FileHandler(logFilePath, true);
            file.setFormatter(new SimpleFormatter());
            logger.addHandler(file);
            logger.log(Level.SEVERE, e.toString(), e);
            file.close();
        } catch (Exception oe) {
            oe.printStackTrace();
            System.exit(0);
        }
    }
}